# FoxCoin (FOX)

An ERC-20 token deployed on Ethereum.

## Details
- Name: FoxCoin
- Symbol: FOX
- Total Supply: 1,000,000,000

## License
MIT